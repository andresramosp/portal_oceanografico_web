import React, { useContext } from "react";
import "../styles/player.css";
import { PlayingContext } from "../providers/PlayingContext";

export const Player = () => {
  const { timeIndex, setTimeIndex, playing } = useContext(PlayingContext);
  return (
    <>
      {playing && (
        <div className="player-container">
          <input
            type="range"
            min="0"
            max="23"
            value={timeIndex}
            onChange={(e) => setTimeIndex(e.target.value)}
          />
        </div>
      )}
    </>
  );
};
